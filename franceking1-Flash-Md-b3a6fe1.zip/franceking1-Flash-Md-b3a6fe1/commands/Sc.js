

/** 

🇫‌🇱‌🇦‌🇸‌🇭‌-🇲‌🇩‌ 

  𝗖𝗼𝗽𝘆𝗿𝗶𝗴𝗵𝘁 (𝗖) 2024.
 𝗟𝗶𝗰𝗲𝗻𝘀𝗲𝗱 𝘂𝗻𝗱𝗲𝗿 𝘁𝗵𝗲  𝗠𝗜𝗧 𝗟𝗶𝗰𝗲𝗻𝘀𝗲;
 𝗬𝗼𝘂 𝗺𝗮𝘆 𝗻𝗼𝘁 𝘂𝘀𝗲 𝘁𝗵𝗶𝘀 𝗳𝗶𝗹𝗲 𝗲𝘅𝗰𝗲𝗽𝘁 𝗶𝗻 𝗰𝗼𝗺𝗽𝗹𝗶𝗮𝗻𝗰𝗲 𝘄𝗶𝘁𝗵 𝘁𝗵𝗲 𝗟𝗶𝗰𝗲𝗻𝘀𝗲.
 𝗜𝘁 𝗶𝘀 𝘀𝘂𝗽𝗽𝗹𝗶𝗲𝗱 𝗶𝗻 𝘁𝗵𝗲 𝗵𝗼𝗽𝗲 𝘁𝗵𝗮𝘁 𝗶𝘁 𝗺𝗮𝘆 𝗯𝗲 𝘂𝘀𝗲𝗳𝘂𝗹.
 * @𝗽𝗿𝗼𝗷𝗲𝗰𝘁_𝗻𝗮𝗺𝗲 : 𝗙𝗹𝗮𝘀𝗵 𝗠𝗗, 𝗮 𝘀𝗶𝗺𝗽𝗹𝗲 𝗮𝗻𝗱 𝗲𝗮𝘀𝘆 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝘂𝘀𝗲𝗿 𝗯𝗼𝘁 
 * @𝗼𝘄𝗻𝗲𝗿: 𝗙𝗿𝗮𝗻𝗰𝗲 𝗞𝗶𝗻𝗴 
 
 **/







'use strict';function _0x5a91(){const _0xa2080d=['https://api.github.com/repos/franceking1/Flash-Md','\x20People\x20are\x20using\x20FLASH-MD.*\x0a\x0a*','20DhyKKs','stargazers_count','58482eDSGXw','31CVqpLl','\x0a*A\x20Total\x20of\x20','sendMessage','2013615ACRzSN','Could\x20not\x20fetch\x20data','forks','../framework/france','3368547DReqgE','5qnwJaV','7774984fIeqTg','stars','json','defineProperty','2450814QEWoxp','log','120972rAqnMV','253DldEuf','fmd','176068bFSyOt','14cQwpkf','\x20People\x20have\x20starred\x20it\x20as\x20a\x20sign\x20of\x20Loving\x20it.*\x0a\x0a*KEEP\x20USING\x20FLASH-MD*\x20\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20*Made\x20With*\x20🤍','__esModule'];_0x5a91=function(){return _0xa2080d;};return _0x5a91();}const _0x33577f=_0x2672;function _0x2672(_0x1727da,_0x3c7296){const _0x5a911f=_0x5a91();return _0x2672=function(_0x2672dc,_0x3d31fb){_0x2672dc=_0x2672dc-0x8f;let _0x131c88=_0x5a911f[_0x2672dc];return _0x131c88;},_0x2672(_0x1727da,_0x3c7296);}(function(_0x5a29e5,_0x42f47f){const _0xaf16b9=_0x2672,_0x3c18bb=_0x5a29e5();while(!![]){try{const _0x9e6c68=parseInt(_0xaf16b9(0x93))/0x1*(-parseInt(_0xaf16b9(0x92))/0x2)+parseInt(_0xaf16b9(0x96))/0x3+parseInt(_0xaf16b9(0xa5))/0x4*(parseInt(_0xaf16b9(0x9b))/0x5)+parseInt(_0xaf16b9(0xa0))/0x6*(parseInt(_0xaf16b9(0xa6))/0x7)+parseInt(_0xaf16b9(0x9c))/0x8+-parseInt(_0xaf16b9(0x9a))/0x9*(parseInt(_0xaf16b9(0x90))/0xa)+parseInt(_0xaf16b9(0xa3))/0xb*(-parseInt(_0xaf16b9(0xa2))/0xc);if(_0x9e6c68===_0x42f47f)break;else _0x3c18bb['push'](_0x3c18bb['shift']());}catch(_0x1454ba){_0x3c18bb['push'](_0x3c18bb['shift']());}}}(_0x5a91,0x96aad));Object[_0x33577f(0x9f)](exports,_0x33577f(0xa8),{'value':!![]});const {france}=require(_0x33577f(0x99));france({'nomCom':_0x33577f(0xa4),'reaction':'😌'},async(_0x3b5c5b,_0x36008e,_0x2f66cd)=>{const _0x448cfe=_0x33577f,_0x5ca71f=_0x448cfe(0xa9),_0x15d782='https://telegra.ph/file/7cc6e55a2ea3d8cd7f30e.jpg',_0x20e692=await fetch(_0x5ca71f),_0x3283f0=await _0x20e692[_0x448cfe(0x9e)]();if(_0x3283f0){const _0x5a2f21={'stars':_0x3283f0[_0x448cfe(0x91)],'forks':_0x3283f0['forks_count']},_0x263678=_0x448cfe(0x94)+_0x5a2f21[_0x448cfe(0x98)]+_0x448cfe(0x8f)+_0x5a2f21[_0x448cfe(0x9d)]+_0x448cfe(0xa7);await _0x36008e[_0x448cfe(0x95)](_0x3b5c5b,{'image':{'url':_0x15d782},'caption':_0x263678});}else console[_0x448cfe(0xa1)](_0x448cfe(0x97));});
